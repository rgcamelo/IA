<?php
class Neurona{

	public $entrada1;
	public $entrada2;
	public $Peso1;
	public $Peso2;
	public $umbral;
	
	public function __construct($e1,$e2,$p1,$p2,$u){
		$this->entrada1=$e1;
		$this->entrada2=$e2;
		$this->Peso1=$p1;
		$this->Peso2=$p2;
		$this->umbral=$u;
	}

	public function Soma(){
		$soma=$this->entrada1*$this->Peso1+$this->entrada2*$this->Peso2;
		$soma=$soma+$this->umbral;
		return $soma;
	}

	public function Activacion($s){
		if($s<=0){
			$activacion=0;
			return $activacion;
		}
		else{
			$activacion=1;
			return $activacion;
		}
	}

	public function infoNeurona(){
		echo "entrada 1:";
		echo $this->entrada1;
		echo "<br>";
		echo "entrada 2:";
        echo $this->entrada2;
		echo "<br>";
		echo "Peso 1:";
        echo $this->Peso1;
		echo "<br>";
		echo "Peso 2:";
		echo $this->Peso2;
		echo "<br>";
		echo "Umbral:";
        echo $this->umbral;
	}


}
?>
<!DOCTYPE html>
<html>
<head>
	<title>PERCEPTRON</title>
	<meta charset="utf-8">
	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
	<link rel="stylesheet" href="libs/morris.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="libs/morris.min.js" charset="utf-8"></script>

</head>
<body>
   <div class="container">
   <h1>Perceptron</h1>
   <hr>

   <div class="row">

   <div class="col-md-6">

   <div class="row">
   <div class="col-md-6">
   <form method="post" action="" enctype="multipart/form-data">
   <p>No Iteracciones: <input type="number" name="Iteracciones" /></p>
   <p>Error Maximo:  <input type="number" step="0.01"  name="Error" /></p>
   <p>Rata Aprendizaje:  <input type="number" step="0.01"  name="Rata" /></p>
    <input type="file" name="archivo"><br>
	<input type="submit" value="Iniciar" name="boton">
   </form>
   </div>
   </div>

   <div class="row">
   <div class="col-md-6">
   <?php 

   if(isset($_POST['boton'])){
	$nombreArchivo= $_FILES['archivo']['name'];
  $fp = fopen($nombreArchivo, "r");
  $iteracciones=$_POST['Iteracciones'];
  $error=$_POST['Error'];
  $r=$_POST['Rata'];
   echo "<br>";
   echo "Interacciones: ".$iteracciones;
   echo "<br>";
   echo "Error Maximo: ".$error;
   echo "<br>";
   echo "Rata de Aprendizaje: ".$r;
   echo "<br>";
echo "<br><table class='table-bordered'>
<tr>
<th>x1</th>
<th>x2</th>
<th>y1</th>
<th>y2</th>
</tr>";
while(!feof($fp)) {

$linea = fgets($fp);
$patron=explode(",",$linea);
echo "
<tr>
<td>".$patron[0]."</td>
<td>".$patron[1]."</td>
<td>".$patron[2]."</td>
<td>".$patron[3]."</td>
</tr>";
}
echo "</table>";
fclose($fp);
   ?>
   </div>
   <div class="col-md-6">
   <?php
   $errormaestro=$error;
   $pesos= array(0,0,0,0);
   $umbrales= array(0,0);
   $rata = $r;
   
   for ($i = 0; $i <= 3; $i++) {
	   $numero=rand(-100,100)/100;
	   $pesos[$i]=$numero;
   }
   
   for ($i = 0; $i <= 1; $i++) {
	   $numero=rand(-100,100)/100;
	   $umbrales[$i]=$numero;
   }
   
   echo "<br><table class='table-bordered'>
<tr>
<th>Pesos</th>
</tr>";
echo "
<tr>
<td>".$pesos[0]."</td>
<td>".$pesos[1]."</td>
</tr>
<tr>
<td>".$pesos[2]."</td>
<td>".$pesos[3]."</td>
</tr>";
echo "</table>";

echo "<br><table class='table-bordered'>
<tr>
<th>Umbrales</th>

</tr>";
echo "
<tr>
<td>".$umbrales[0]."</td>
<td>".$umbrales[1]."</td>
</tr>";
echo "</table>";
   ?>
   </div>
   </div>
       

   <div class="row">
   <div id="aleatorio" class="col-md-6">
    
   </div>
   </div>
   
   </div>
   <div class="col-md-6">
   <h2>Grafica de linea</h2>
   <div id="myfirstchart">
   </div>
   </div>
   </div>
   </div>

<?php
$i=0;
$Graficar=array();
$parar=false;
while($i<$iteracciones and $parar==false){
$errorinteraccion=0;

$fp=fopen($nombreArchivo,'r');
while(!feof($fp) ) {

	$linea = fgets($fp);	

	$patron=explode(",",$linea);
	
	$neurona1 = new Neurona($patron[0],$patron[1],$pesos[0],$pesos[2],$umbrales[0]);
//$neurona1->infoNeurona();
//echo "<br>";
//echo "Funcion Soma - Umbral:";
$Soma1=$neurona1->Soma();
//echo $Soma1;
//echo "<br>";
//echo "Funcion Activacion:";
$Activacion1=$neurona1->Activacion($Soma1);
//echo $Activacion1;
//echo "<br>";
//echo "Salida deseada:",$patron[2];
//echo "<br>";
//echo "Error Lineal:";
$errorlineal1=$patron[2]-$Activacion1;
//echo $errorlineal1;


//echo "<br>";
//echo "<br>";
$neurona2 = new Neurona($patron[0],$patron[1],$pesos[1],$pesos[3],$umbrales[1]);
//$neurona2->infoNeurona();
//echo "<br>";
//echo "Funciona Soma - Umbral:";
$Soma2=$neurona2->Soma();
//echo $Soma2;
//echo "<br>";
//echo "Funcion Activacion:";
$Activacion2=$neurona2->Activacion($Soma2);
//echo $Activacion2;
//echo "<br>";
//echo "Salida deseada:",$patron[3];
//echo "<br>";
//echo "Error Lineal:";
$errorlineal2=$patron[3]-$Activacion2;
//echo $errorlineal2;
//echo "<br>";
//echo "<br>";

$pesos[0]=$pesos[0]+$rata*$errorlineal1*$patron[0];
$pesos[2]=$pesos[2]+$rata*$errorlineal1*$patron[1];
$pesos[1]=$pesos[1]+$rata*$errorlineal2*$patron[0];
$pesos[3]=$pesos[3]+$rata*$errorlineal2*$patron[1];

$umbrales[0]=$umbrales[0]+$rata*$errorlineal1;
$umbrales[1]=$umbrales[1]+$rata*$errorlineal2;
	
$errorpatron=(abs($errorlineal1)+abs($errorlineal2))/2;
$errorinteraccion=$errorinteraccion+$errorpatron;
//echo "Error del patron:",$errorpatron;
//echo "<br>";
//echo "<br>";
	}
fclose($fp);

$errori=$errorinteraccion/4;

if($errori <= $errormaestro){
  $parar=true;
}
//echo "<br>";
//echo "<br>";
//echo "Error de interaccion:",$errori;
$Graficar[$i]=$errori;
//echo "<br>";
//echo "<br>";
$i++;
}

$ultimospesos;
for ($i = 0; $i < sizeof($pesos); $i++) {
 $ultimospesos[$i]=$pesos[$i];  
}

$ultimosumbrales;
for ($i = 0; $i < sizeof($umbrales); $i++) {
 $ultimosumbrales[$i]=$umbrales[$i];  
}


echo "<div class='container'>
<div class='row'>
   <div class='col-md-6'>";
   echo "<br><table class='table-bordered'>
   <tr>
   <th>Ultimos Pesos</th>
   </tr>";
   echo "
   <tr>
   <td>".$ultimospesos[0]."</td>
   <td>".$ultimospesos[1]."</td>
   </tr>
   <tr>
   <td>".$ultimospesos[2]."</td>
   <td>".$ultimospesos[3]."</td>
   </tr>";
   echo "</table>";
   echo "</div>
   </div>
   </div>";

   echo "<div class='container'>
   <div class='row'>
      <div class='col-md-6'>";
      echo "<br><table class='table-bordered'>
      <tr>
      <th>Ultimos Pesos</th>
      </tr>";
      echo "
      <tr>
      <td>".$ultimosumbrales[0]."</td>
      <td>".$ultimosumbrales[1]."</td>
      </tr>";
      echo "</table>";
      echo "</div>
      </div>
      </div>";
   

   $fp = fopen("ultimospesos.txt", "w");
for ($i = 0; $i < sizeof($ultimospesos); $i++) {
   fputs($fp,$ultimospesos[$i].",");
}
echo "Pesos Guardados";
fclose($fp);

$fp = fopen("ultimosumbrales.txt", "w");
for ($i = 0; $i < sizeof($ultimosumbrales); $i++) {
   fputs($fp,$ultimosumbrales[$i].",");
}
echo "Umbrales Guardados";
fclose($fp);

/*for ($i = 0; $i < sizeof($Graficar); $i++) {
  echo "<br>";
  echo $Graficar[$i];  
}
*/


   }
?>

</body>
</html>
<script>
//var arrayJS=<?php echo json_encode($Graficar);?>;
//numero = Number(arrayJS[1])+1;
//document.write("<br>"+numero);



var morris1 = new Morris.Line({
  // ID of the element in which to draw the chart.
  element: 'myfirstchart',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.
  
  data: [
   <?php
    for ($i = 0; $i < sizeof($Graficar); $i++){
      $c="{iteraccion:".$i.", value:".$Graficar[$i]."},"; 
      echo $c;
      echo "\n"; 
    }
    ?>  
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'iteraccion',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Value'],
  goals: [<?php echo $errormaestro?>, 0]
});



</script>

